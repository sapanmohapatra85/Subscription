package com.techm.subscription.poc.util;

public interface ISubscriptionConstant {
	
	public static final int NO_OF_CHARS = 2;

}
