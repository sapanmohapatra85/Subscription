package com.techm.subscription.poc.service;

import javax.servlet.http.HttpServletRequest;


public interface ISubscriptionService {

	
	String getOrderDetails(HttpServletRequest request);

	String truncate(String orderDetails, Integer i);
	
	
	
}
