package com.techm.subscription.poc.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.techm.subscription.poc.service.ISubscriptionService;

@RestController
//@Controller

@Configuration
@ComponentScan("com.techm.subscription.poc.service")
public class SubscriptionController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SubscriptionController.class);
	@Autowired
	private ISubscriptionService iSubscriptionService;
	
	public static final Integer NO_OF_CHARS = 25;

	/**
	 * Test Method
	 */
	@RequestMapping(value = "/test", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String test() {

		return "Testing";
	}


	@RequestMapping (value = "/subscribe" , method = RequestMethod. GET )
	public String subscribe(HttpServletRequest request ) {
	String truncatedOrderDetails = null;
	try{
	String orderDetails = iSubscriptionService.getOrderDetails( request );
     truncatedOrderDetails = iSubscriptionService.truncate(orderDetails, NO_OF_CHARS);
	
	}catch(Exception e){
		e.printStackTrace();
	}
	
	return truncatedOrderDetails;

	
	}


}
