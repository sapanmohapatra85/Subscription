package com.techm.subscription.poc.service.impl;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.techm.subscription.poc.service.ISubscriptionService;
import com.techm.subscription.poc.util.ISubscriptionConstant;

@Component
public class SubscriptionServiceImpl implements ISubscriptionService {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SubscriptionServiceImpl.class);

	@Override
	public String getOrderDetails(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String orderDetails = "123456789012345678901234567890";
		return orderDetails;
	}

	@Override
	public String truncate(String str, Integer noOfChar) {
		// TODO Auto-generated method stub
		 String outputStr="";
		try{
		 
			  
	           String middleString = " ... (truncated) ... ";//21 chars
	           if(str.length() == noOfChar){
	                  outputStr = str;
	                  
	           }else if(str.length() < noOfChar){
	                  outputStr = str;
	           }else if(str.length() > noOfChar){
	        	   if(middleString.length()>noOfChar){
	        		   outputStr = str;
	        	   }
	        	   else{
	        		  int displayChars = noOfChar - middleString.length();
	         	      int leftCharNums = Math.round(displayChars/2);
	         	      int rightCharNums = displayChars - leftCharNums;
	         	      
	                   String firstStr= str.substring(0, leftCharNums);
	                   System.out.println("First String : " + firstStr);
	                   String lastStr = str.substring(str.length()-rightCharNums);
	                   System.out.println("Last String : " + lastStr);
	                   //outputStr=firstStr;
	                  /* for(int i=0; i < (noOfChar - (firstStr.length()+lastStr.length())); i ++){
	                         outputStr=outputStr+ ".";
	                   }*/
	                   outputStr=firstStr+middleString+lastStr;
	        	   }
	        	      
	           }
	           System.out.println("Final String : "+ outputStr);
          LOGGER.info("Final String : "+ outputStr);
          
		}
		catch(Exception e){
			e.printStackTrace();
		}
          return outputStr;
      
	}
	
	
	
}
